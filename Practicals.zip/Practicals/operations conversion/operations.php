<?php

// Initial values
$integerValue = 42;
$stringValue = "123";
$floatValue = 3.14;

// Display initial values
echo "<h2>Initial Values</h2>";
echo "Integer: $integerValue<br>";
echo "String: $stringValue<br>";
echo "Float: $floatValue<br><br>";

// 1. Integer to String Conversion
$intToString = (string)$integerValue; // Using type casting
echo "<h2>Integer to String Conversion</h2>";
echo "Integer: $integerValue<br>";
echo "Converted to String: '$intToString'<br><br>";

// 2. String to Integer Conversion
$stringToInt = (int)$stringValue; // Using type casting
echo "<h2>String to Integer Conversion</h2>";
echo "String: '$stringValue'<br>";
echo "Converted to Integer: $stringToInt<br><br>";

// 3. Float to Integer Conversion
$floatToInt = (int)$floatValue; // Using type casting
echo "<h2>Float to Integer Conversion</h2>";
echo "Float: $floatValue<br>";
echo "Converted to Integer: $floatToInt<br><br>";

// Additional Conversion Functions
echo "<h2>Using Conversion Functions</h2>";

// Convert to Integer using intval()
$convertedStringToInt = intval($stringValue);
$convertedFloatToInt = intval($floatValue);

echo "Using intval() to convert String to Integer: $convertedStringToInt<br>";
echo "Using intval() to convert Float to Integer: $convertedFloatToInt<br>";
?>